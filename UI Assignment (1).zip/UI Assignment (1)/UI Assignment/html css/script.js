
    function formValidation()
    {
   
    var uname = document.registration.username;
    var ucountry = document.registration.country;
    var uemail = document.registration.email;
    var uabout = document.registration.desc;
    var udob = document.registration.birthday;
    let checkboxes = document.querySelectorAll('input[name="val"]:checked');
    
   
    if(allLetter(uname)== true && countryselect(ucountry)==true && ValidateEmail(uemail)==true && about(uabout)==true && 
    dob(udob)==true && checkbox(checkboxes)==true )
    {
        return true;
  
    }
    else 
    {
        return false;
    }
}
    
function checkbox(checkboxes)
{
    let values = [];
    checkboxes.forEach((checkbox) => 
    {
        values.push(checkbox.value);
    });
try
{

if(values=="")
{
    throw("type can not be empty");
    return false;
}

else
{
return true;
}


}

catch(err)
{
    alert(err);
}

}


 function about(uabout)
 {
    try
    {
    if (uabout.value.length == 0)
    { 
       throw("about field can not be empty");  	
       return false; 
    }  	
    else
    {
    return true;
    }
}
catch(err)
{
    alert(err);

}
 }
    
    function allLetter(uname)
    { 
    var letters = /^[A-Za-z]+$/;


    try
    {
    if(uname.value.match(letters))
    {
    return true;
    }
    else
    {
    throw('Username must have alphabet characters only');
    uname.focus();
    return false;
    }
    }
    catch(err)
{
    alert(err);

}

}
  
    function countryselect(ucountry)
    {
        try
        {
    if(ucountry.value == "Default")
    {
    throw('Select your country from the list');
    ucountry.focus();
    return false;
    }
    else
    {
    return true;
    }
}

catch(err)
{
    alert(err);

}
    }
   
    function ValidateEmail(uemail)
    {
    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    try
    {

    if(uemail.value.match(mailformat))
    {
    return true;
    }
    else
    {
    throw("You have entered an invalid email address!");
    uemail.focus();
    return false;
    }
}
catch(err)
{
    alert(err);

}
    } 

    

    function dob(udob)
    {
        try
        {
        if (udob.value.length == 0)
    { 
       alert("DOB can not be empty");  	
       return false; 
    }  	
    else
    {
    return true;
    }
}
catch(err)
{
    alert(err);

}

    }
    
    